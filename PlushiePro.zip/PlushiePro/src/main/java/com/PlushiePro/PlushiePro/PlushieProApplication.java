package com.PlushiePro.PlushiePro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlushieProApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlushieProApplication.class, args);
	}

}
