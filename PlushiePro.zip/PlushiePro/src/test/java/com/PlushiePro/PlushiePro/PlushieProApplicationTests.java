package com.PlushiePro.PlushiePro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlushieProApplicationTests {

	@Test
	void contextLoads() {
	}

}
